#!/bin/bash 
ssh lrn12@zeus.cs.txstate.edu
sftp lrn12@zeus.cs.txstate.edu
