#!/usr/bin/perl
# My first perl script

print STDOUT "Enter a numbner: ";
$number = <STDIN>;
print STDOUT "The number is: $number\n";
